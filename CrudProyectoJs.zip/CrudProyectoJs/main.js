
const formulario = document.getElementById("formulario");
const codigo = document.getElementById("codigo");
const nombre = document.getElementById("nombre");
const descripcion = document.getElementById("descripcion");
const fecha = document.getElementById("fecha");
const tipo = document.getElementById("tipo");
const btnAdd = document.getElementById("btn-add");

const tBody = document.getElementById("tbody");

const modelAdd = document.getElementById("model-add");
const btnCerrarAdd = document.getElementById("btn-cerrar-add");

const formularioEdit = document.getElementById("formulario-edit");
const modelEdit = document.getElementById("model-edit");
const btnCerrarEdit = document.getElementById("btn-cerrar-edit");
const codigoEdit = document.getElementById("codigo-edit");
const nombreEdit = document.getElementById("nombre-edit");
const descripcionEdit = document.getElementById("descripcion-edit");
const fechaEdit = document.getElementById("fecha-edit");
const tipoEdit = document.getElementById("tipo-edit");

const buscador = document.getElementById("buscador");
const barraBusqueda = document.getElementById("barra-busqueda");

const arrayProyectos = [];

Leer();

formulario.addEventListener('submit', (e) => {
  e.preventDefault();

  const proyecto = {
    cod: codigo.value,
    name: nombre.value,
    descrip: descripcion.value,
    date: fecha.value,
    type: tipo.value
  }

  arrayProyectos.push(proyecto);

  alert("el Proyecto ha sido Agregado con Éxito!");

  Leer();

  if (modelAdd.className === "model model-add-show") {
    modelAdd.classList.remove("model-add-show");
  }
});

btnAdd.addEventListener('click', (e) => {
  e.preventDefault();

  if (modelAdd.className === "model") {
    modelAdd.classList.add("model-add-show");
  }

})

btnCerrarAdd.addEventListener('click', (e) => {
  e.preventDefault();

  if (modelAdd.className === "model model-add-show") {
    modelAdd.classList.remove("model-add-show");
  }
})


function On(elemento, evento, selector, manejador) {
  elemento.addEventListener(evento, e => {
    if (e.target.closest(selector)) {
      manejador(e);
    }
  })
}

On(document, 'click', '#btn-edit', e => {
  const valor = e.target.parentNode.value;

  let pos = -1;

  arrayProyectos.forEach((elem, index) => {
    if (valor === elem.cod) { 
      codigoEdit.value = elem.cod;
      nombreEdit.value = elem.name;
      descripcionEdit.value = elem.descrip;
      fechaEdit.value = elem.date;
      tipoEdit.value = elem.type;

      pos = index;
    }
  })

  if (modelEdit.className === "model") {
    modelEdit.classList.add("model-edit-show");
  }
  
  formularioEdit.addEventListener('submit', (e) => {
    e.preventDefault();

    arrayProyectos[pos].cod = codigoEdit.value;
    arrayProyectos[pos].name = nombreEdit.value;
    arrayProyectos[pos].descrip = descripcionEdit.value;
    arrayProyectos[pos].date = fechaEdit.value;
    arrayProyectos[pos].type = tipoEdit.value;


    alert("el Proyecto ha sido Actualizado con Éxito!");

    Leer();

    if (modelEdit.className === "model model-edit-show") {
      modelEdit.classList.remove("model-edit-show");
    }

  })

})

btnCerrarEdit.addEventListener('click', (e) => {
  e.preventDefault();

  if (modelEdit.className === "model model-edit-show") {
    modelEdit.classList.remove("model-edit-show");
  }
})

On(document, 'click', '#btn-delete', e => {
  const valor = e.target.parentNode.value;

  let comfirm = confirm("¿Desea Eliminar este Proyecto?");
  if (comfirm == true) {
    arrayProyectos.forEach((elem, index) => {
      if (valor === elem.cod) {
        arrayProyectos.splice(index, 1);
        return;
      }
    })
  }

  Leer();
  console.log(arrayProyectos);
})



buscador.addEventListener('submit', (e) => {
  e.preventDefault();

  let pos = -1;
  let resultado = "";

  arrayProyectos.forEach((elem, index) => {
    if (barraBusqueda.value === elem.cod) {
      pos = index;
      return;
    }
  })

  if (pos != -1) {
    resultado = `<tr>
                    <td>${arrayProyectos[pos].cod}</td>
                    <td>${arrayProyectos[pos].name}</td>
                    <td>${arrayProyectos[pos].descrip}</td>
                    <td>${arrayProyectos[pos].date}</td>
                    <td>${arrayProyectos[pos].type}</td>
                    <td><button type="button" id="btn-edit" value="${arrayProyectos[pos].cod}"><i class="bi bi-pencil-square"></i></button> <button type="button" id="btn-delete" value="${arrayProyectos[pos].cod}"><i class="bi bi-trash"></i></button></td>
                  </tr>`;

    tBody.innerHTML = resultado;
  } else {
    let texto = "No se ha encontrado dicho Proyecto";

    tBody.innerHTML = texto;
  }
});


function Leer() {
  let resultado = "";

  arrayProyectos.forEach(elemento => {
    resultado += `<tr>
                    <td>${elemento.cod}</td>
                    <td>${elemento.name}</td>
                    <td>${elemento.descrip}</td>
                    <td>${elemento.date}</td>
                    <td>${elemento.type}</td>
                    <td><button type="button" id="btn-edit" value="${elemento.cod}"><i class="bi bi-pencil-square"></i></button> <button type="button" id="btn-delete" value="${elemento.cod}"><i class="bi bi-trash"></i></button></td>
                  </tr>`
  });

  tBody.innerHTML = resultado;
}
